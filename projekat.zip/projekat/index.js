const express = require('express');

const app = express();

const router = express.Router();

app.use(express.static('public'));

app.get('/', function (req, res) {    
    res.sendFile(__dirname+'/public/index.html');    
});
app.get('/index', function (req,  res)  {
    res.sendFile(__dirname+'/public/index.html')
});
app.get('/igrica', function (req,  res)  {
    res.sendFile(__dirname+'/public/igrica.html');
});
app.get('/onama', function (req,  res)  {
    res.sendFile(__dirname+'/public/onama.html');
});
app.get('/rezultati', function (req,  res)  {
    res.sendFile(__dirname+'/public/rezultati.html');
});

app.listen(3000, () => {
    console.log("Server started");
});
   